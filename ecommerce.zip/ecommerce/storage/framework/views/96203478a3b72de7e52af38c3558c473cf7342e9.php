


<?php $__env->startSection('content'); ?>


<div class="dashboardContentContainer">

    <div class="dashboardHeader">



        <div class="dashboardHeaderDetails">

            <p>Somename</p>
            <form action="<?php echo e(url('/logout')); ?>" method="POST">
                <?php echo csrf_field(); ?>
                <button type="submit">Log Out</button>
            </form>
        </div>



    </div>

    <div class="dashboardDataContainer">

        <div class="data">

            <p class="dataHeading">Total Order</p>
            <p><?php echo e($ordersCount); ?></p>

        </div>

        <div class="data">

            <p class="dataHeading">Total Earned</p>
            <p>$<?php echo e($totalEarned); ?></p>

        </div>


        <div class="data">

            <p class="dataHeading">Total Subscribes</p>
            <p><?php echo e($subscriberCount); ?></p>

        </div>

        <div class="data">

            <p class="dataHeading">Total Products</p>
            <p><?php echo e($productsCount); ?></p>

        </div>



    </div>

    <div class="dashboardGraphSection">

        <canvas id="myChart"></canvas>

    </div>


</div>


<?php $__env->stopSection(); ?>


<?php $__env->startSection('scripts'); ?>
<script src="https://cdn.jsdelivr.net/npm/chart.js"></script>
<script type='text/javascript'>
    let myChart = document.querySelector('#myChart');




    const barChart = new Chart(myChart, {



        type: 'line',
        data: {

            labels: [1, 2, 3, 4, 5, 6, 7, 8, 9, 10, 11, 12, 13, 14, 15, 16, 17, 18, 19, 20, 21],
            datasets: [{
                label: '',
                data: ["<?php echo e($recordsArray[20]); ?>", "<?php echo e($recordsArray[19]); ?>", "<?php echo e($recordsArray[18]); ?>", "<?php echo e($recordsArray[17]); ?>",
                    "<?php echo e($recordsArray[16]); ?>", "<?php echo e($recordsArray[15]); ?>", "<?php echo e($recordsArray[14]); ?>", "<?php echo e($recordsArray[13]); ?>",
                    "<?php echo e($recordsArray[12]); ?>", "<?php echo e($recordsArray[11]); ?>", "<?php echo e($recordsArray[10]); ?>",
                    "<?php echo e($recordsArray[9]); ?>", "<?php echo e($recordsArray[8]); ?>", "<?php echo e($recordsArray[7]); ?>", "<?php echo e($recordsArray[6]); ?>", "<?php echo e($recordsArray[5]); ?>", "<?php echo e($recordsArray[4]); ?>",
                    "<?php echo e($recordsArray[3]); ?>", "<?php echo e($recordsArray[2]); ?>", "<?php echo e($recordsArray[1]); ?>", "<?php echo e($todaysRecordCount); ?>",
                ],
                fill: false,
                tension: 0.1,
                backgroundColor: "rgba(115, 96, 235, 0.57)",
                borderColor: '#715eeb',
                fill: true,


            }, ],



        },
        options: {}

    })
</script>

<?php $__env->stopSection(); ?>
<?php echo $__env->make('layouts.dashboardLayout', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\Users\tekh2\Desktop\ecommerce\ecommerce\resources\views/dashboard.blade.php ENDPATH**/ ?>