


<?php $__env->startSection('content'); ?>


<div class="dashboardContentContainer">

    <div class="dashboardHeader">

        <div class="dashboardHeaderDetails">

            <p>Somename</p>
            <form action="<?php echo e(url('/logout')); ?>" method="POST">
                <?php echo csrf_field(); ?>
                <button type="submit">Log Out</button>
            </form>

        </div>



    </div>


    <div class="orderViewContainer">


        <div class="orderView">

            <h2 class="text-center">#<?php echo e($order->id); ?></h2>
            <p> User First Name:<strong> <?php echo e($order->userFirstName); ?></strong> </p>
            <p> User Last Name:<strong> <?php echo e($order->userLastName); ?></strong> </p>
            <p> User Email: <strong><?php echo e($order->userEmail); ?> </strong> </p>
            <p> User Address:<strong> <?php echo e($order->userAddress); ?></strong> </p>




            <?php $__currentLoopData = $orderProducts; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $product): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>

            <?php

            $i = 0;

            ?>
            <div class="orderViewProductDetails">
                <p class="checkoutProductName"> <?php echo e($product->name); ?> <br>
                    <small> <strong> QTY : <?php echo e($orderQuantities[$i]); ?> </strong></small> <br>

                </p>

                <img class="orderViewProductImage" class="checkoutProductImage" src="<?php echo e(url('storage/images/'.$product->mainImage)); ?>" alt="">

                <p value="20" class="checkoutProductValue">$<?php echo e($product->price * $orderQuantities[$i]); ?></p>
                <?php

                $i = $i + 1;

                ?>
            </div>


            <p> Total Price: $<?php echo e($order->price); ?></strong> </p>

            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
            <p> User Phone: <strong><?php echo e($order->userPhone); ?></strong> </p>
            <p> User Company: <strong><?php echo e($order->company); ?></strong> </p>
            <p> User Apartment:<strong> <?php echo e($order->userApartMent); ?></strong> </p>
            <p> User City:<strong> <?php echo e($order->city); ?></strong> </p>
            <p> User Country:<strong> <?php echo e($order->country); ?></strong> </p>
            <p> Postal Code:<strong> <?php echo e($order->postalCode); ?></strong> </p>
            <p> Date: <strong><?php echo e($order->created_at->format('j F Y')); ?></strong> </p>




        </div>


    </div>


</div>


<?php $__env->stopSection(); ?>
<?php echo $__env->make('layouts.dashboardLayout', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\Users\tekh2\Desktop\ecommerce\ecommerce\resources\views/orderview.blade.php ENDPATH**/ ?>