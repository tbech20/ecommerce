<!DOCTYPE html>
<html lang="en">

<head>
    <meta charset="UTF-8">
    <meta http-equiv="X-UA-Compatible" content="IE=edge">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Dashboard</title>
    <!-- Styles -->
    <link href="<?php echo e(asset('/css/dashboardStyles.css')); ?>" rel="stylesheet">
    <!-- Styles -->
    <!-- Fonts -->
    <link href="https://fonts.googleapis.com/css2?family=Poppins&display=swap" rel="stylesheet">
    <!-- Fonts -->
    <!-- Font awesome -->
    <link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/5.15.3/css/all.min.css" integrity="sha512-iBBXm8fW90+nuLcSKlbmrPcLa0OT92xO1BIsZ+ywDWZCvqsWgccV3gFoRBv0z+8dLJgyAHIhR35VZc2oM/gI1w==" crossorigin="anonymous" />
    <!-- Font awesome -->
    <!-- Bootstrap Styles -->
    <link rel="stylesheet" href="https://stackpath.bootstrapcdn.com/bootstrap/4.4.1/css/bootstrap.min.css" integrity="sha384-Vkoo8x4CGsO3+Hhxv8T/Q5PaXtkKtu6ug5TOeNV6gBiFeWPGFN9MuhOf23Q9Ifjh" crossorigin="anonymous">
    <!-- Bootstrap  Styles -->

</head>

<body>

    <div class="dashboardContainer">

        <div class="sidebar">

            <img class="dashboardLogo" src="<?php echo e(asset('images/logo.png')); ?>" alt="">

            <div class="sidearSection">



                <div class="sidebarLinks">

                    <a class="<?php if ($page == 'dashboard') {
                                    echo "sidebarActive";
                                } ?>" href="<?php echo e(asset('admin/dashboard')); ?>">Dashboard</a>
                    <a class="<?php

                                if ($page == 'addproduct') {
                                    echo "sidebarActive";
                                }

                                ?>" href="<?php echo e(asset('admin/addproduct')); ?>">Add Product</a>

                    <a class="<?php

                                if ($page == 'allproducts') {
                                    echo "sidebarActive";
                                }
                                ?>" href="<?php echo e(asset('admin/allproducts')); ?>">All Products</a>

                    <a class="<?php

                                if ($page == 'promocodes') {
                                    echo "sidebarActive";
                                }
                                ?>" href="<?php echo e(asset('admin/promocodes')); ?>">Promo Codes</a>

                    <a class="<?php

                                if ($page == 'orders') {
                                    echo "sidebarActive";
                                }
                                ?>" href="<?php echo e(asset('admin/orders')); ?>">Orders</a>


                    <a class="<?php

                                if ($page == 'tickets') {
                                    echo "sidebarActive";
                                }
                                ?>" href="<?php echo e(asset('admin/tickets')); ?>">Tickets</a>


                    <a class="<?php

                                if ($page == 'subscribers') {
                                    echo "sidebarActive";
                                }
                                ?>" href="<?php echo e(asset('admin/subscribers')); ?>">Subscribers</a>


                    <a class="<?php

                                if ($page == 'credentials') {
                                    echo "sidebarActive";
                                }
                                ?>" href="<?php echo e(asset('admin/credentials')); ?>">Credentials</a>

                </div>

            </div>

        </div>

        <?php echo $__env->yieldContent('content'); ?>


    </div>


    <script src="https://code.jquery.com/jquery-3.4.1.slim.min.js" integrity="sha384-J6qa4849blE2+poT4WnyKhv5vZF5SrPo0iEjwBvKU7imGFAV0wwj1yYfoRSJoZ+n" crossorigin="anonymous"></script>
    <?php echo $__env->yieldContent('scripts'); ?>

</body>

</html><?php /**PATH C:\Users\tekh2\Desktop\ecommerce\ecommerce\resources\views/layouts/dashboardLayout.blade.php ENDPATH**/ ?>