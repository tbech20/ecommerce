


<?php $__env->startSection('styles'); ?>

<link href="<?php echo e(asset('/css/contact.css')); ?>" rel="stylesheet">

<?php $__env->stopSection(); ?>


<?php $__env->startSection('content'); ?>


<div class="contactContaier">

    <div class="contact">


        <div class="contactLeft">

            <form action="<?php echo e(url('/createticket')); ?>" method="POST" class="contactForm">
                <?php echo csrf_field(); ?>


                <div class="form-group">
                    <label for="email">Email</label>
                    <input required type="email" class="form-control" name='email' placeholder="email">
                </div>



                <div class="form-group">

                    <label for="message">Description</label>
                    <textarea required type="text" name='message' rows="10" class="form-control">
                    </textarea>
                </div>

                <button class="sendMessage"> Send </button>

                <?php if(session('successfull')): ?>
                <p class="successfullMessage"><?php echo e(session('successfull')); ?></p>

                <?php endif; ?>

            </form>


        </div>


    </div>


</div>


<?php $__env->stopSection(); ?>

<?php $__env->startSection('scripts'); ?>

<script type='text/javascript' defer>
    $('document').ready(function() {
        $('textarea').each(function() {
            $(this).val($(this).val().trim());
        });
    });
</script>
<?php $__env->stopSection(); ?>
<?php echo $__env->make('layouts.appLayout', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\Users\tekh2\Desktop\ecommerce\ecommerce\resources\views/contact.blade.php ENDPATH**/ ?>