

<?php $__env->startSection('styles'); ?>

<link href="<?php echo e(asset('/css/checkout.css')); ?>" rel="stylesheet">

<?php $__env->stopSection(); ?>


<?php $__env->startSection('content'); ?>


<div class="checkoutContainer noproductsCheckout">

    <div class="checkout">

    </div>


</div>


<?php $__env->stopSection(); ?>
<?php echo $__env->make('layouts.appLayout', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\Users\tekh2\Desktop\ecommerce\ecommerce\resources\views/noproducts.blade.php ENDPATH**/ ?>