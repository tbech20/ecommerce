

<?php $__env->startSection('styles'); ?>

<link href="<?php echo e(asset('/css/checkout.css')); ?>" rel="stylesheet">

<?php $__env->stopSection(); ?>


<?php $__env->startSection('content'); ?>


<div class="checkoutContainer">



    <div class="checkout">







        <form action="<?php echo e('/proceed'); ?>" class="checkoutLeft" method="POST">
            <?php echo csrf_field(); ?>

            <h2>Billing Address</h2>


            <div class="checkoutDoubleInput">

                <input type="text" name='firstname' required class="checkoutInput form-control" placeholder="First Name">
                <input type="text" name='lastname' required class="checkoutInput form-control" placeholder="Last Name">


            </div>

            <div class="checkoutLongInputContainer">
                <input type="email" name='email' required class="checkoutInput form-control" placeholder="Email">
                <input type="text" name='company' class="checkoutInput form-control" placeholder="Company (optional)">
                <input type="text" name='address' required class="checkoutInput form-control" placeholder="Adrress">

                <input type="text" name='apartment' required class="checkoutInput form-control" placeholder="Apartment">
                <input type="text" name='city' required class="checkoutInput form-control" placeholder="City">
            </div>
            <div class="checkoutDoubleInput">

                <select type="text" name='country' required class="checkoutInput form-control" placeholder="Country">


                    <option value="Argentina">Argentina</option>
                    <option value="Spain">Spain</option>


                </select>
                <input type="text" name='postalcode' required class="checkoutInput form-control" placeholder="Postal Code">

            </div>
            <input type="text" name='phone' required class="checkoutInput form-control" placeholder="Phone">


            <?php $__currentLoopData = $errors->all(); $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $error): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
            <li><?php echo e($error); ?></li>
            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>

            <button class="payBtn">Proceed To Checkout</button>




        </form>


        <div class="checkoutRight">

            <p class="checkoutRightHeading">Order Summary</p>

            <?php $__currentLoopData = $products; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $product): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>


            <div class="checkoutProductDetails">

                <img class="checkoutProductImage" src="<?php echo e(url('storage/images/'.$product[0]['mainImage'])); ?>" alt="">
                <p class="checkoutProductName"><?php echo e($product[0]['name']); ?> <br>
                    <small> <strong> QTY : <?php echo e($product[1]); ?> </strong></small> <br>

                <form action="<?php echo e(url('/remove/' . $product[0]['id'])); ?>" method="POST"><?php echo csrf_field(); ?>
                    <button type="submit" class="checkoutDecrease">&#x2715;</button>
                </form>


                </p>
                <p value="<?php echo e($product[0]['price'] * $product[1]); ?>" class="checkoutProductValue">$<?php echo e($product[0]['price'] * $product[1]); ?></p>

            </div>

            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>

            <hr>

            <div class="checkoutRightInfo">

                <p>Subtotal</p>

                <p class="subTotal">$<?php echo e($total); ?></p>

            </div>

            <hr>

            <div class="checkoutRightInfo">

                <p>Discount <br>

                    <?php if(session('hasCoupon')): ?>

                    <small>Coupon : <?php echo e(session('hasCoupon')); ?></small>
                </p>
                <p><?php echo e(session('discount')); ?>%</p>
                <?php endif; ?>

            </div>
            <hr>
            <div class="checkoutRightInfo">

                <p>Total</p>
                <?php if(session('hasCoupon')): ?>

                <p>$<?php echo e($total - (session('discount') * $total / 100)); ?></p>

                <?php else: ?>

                <p>$<?php echo e($total); ?></p>
                <?php endif; ?>


            </div>

            <p class="demo"></p>

            <hr>

            <form class="applyCouponForm" action="<?php echo e(url('/checkcoupon')); ?>" method="POST">
                <div class="checkoutCouponContainer">


                    <?php echo csrf_field(); ?>
                    <input type="text" class="coupon form-control" name='coupon' placeholder="Coupon">
                    <button class="applyCouponBtn">Apply</button>

                </div>
            </form>







        </div>

    </div>

</div>


<?php $__env->stopSection(); ?>
<?php echo $__env->make('layouts.appLayout', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\Users\tekh2\Desktop\ecommerce\ecommerce\resources\views/checkout.blade.php ENDPATH**/ ?>