

<?php $__env->startSection('styles'); ?>

<link href="<?php echo e(asset('/css/checkout.css')); ?>" rel="stylesheet">

<?php $__env->stopSection(); ?>


<?php $__env->startSection('content'); ?>


<div class="checkoutContainer">



    <div class="checkout">







        <div class="checkoutLeft">
            <?php echo csrf_field(); ?>

            <a class="payBtn" href="<?php echo $preference->init_point; ?>">Pay with Mercado Pago</a>
        </div>


        <div class="checkoutRight">

            <p class="checkoutRightHeading">Order Summary</p>

            <?php $__currentLoopData = $products; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $product): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>


            <div class="checkoutProductDetails">

                <img class="checkoutProductImage" src="<?php echo e(url('storage/images/'.$product[0]['mainImage'])); ?>" alt="">
                <p class="checkoutProductName"><?php echo e($product[0]['name']); ?> <br>
                    <small> <strong> QTY : <?php echo e($product[1]); ?> </strong></small> <br>



                </p>
                <p value="<?php echo e($product[0]['price'] * $product[1]); ?>" class="checkoutProductValue">$<?php echo e($product[0]['price'] * $product[1]); ?></p>

            </div>

            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>

            <hr>

            <div class="checkoutRightInfo">

                <p>Subtotal</p>

                <p class="subTotal">$<?php echo e($total); ?></p>

            </div>

            <hr>

            <div class="checkoutRightInfo">

                <p>Discount <br>

                    <?php if(session('hasCoupon')): ?>

                    <small>Coupon : <?php echo e(session('hasCoupon')); ?></small>
                </p>
                <p><?php echo e(session('discount')); ?>%</p>
                <?php endif; ?>

            </div>
            <hr>
            <div class="checkoutRightInfo">

                <p>Total</p>
                <?php if(session('hasCoupon')): ?>

                <p>$<?php echo e($total - (session('discount') * $total / 100)); ?></p>

                <?php else: ?>

                <p>$<?php echo e($total); ?></p>
                <?php endif; ?>


            </div>

            <p class="demo"></p>

            <hr>

            <form class="applyCouponForm" action="<?php echo e(url('/checkcoupon')); ?>" method="POST">
                <div class="checkoutCouponContainer">


                    <?php echo csrf_field(); ?>
                    <input type="text" class="coupon form-control" name='coupon' placeholder="Coupon">
                    <button class="applyCouponBtn">Apply</button>

                </div>
            </form>







        </div>

    </div>

</div>


<?php $__env->stopSection(); ?>


<?php $__env->startSection('scripts'); ?>


<script src="https://sdk.mercadopago.com/js/v2"></script>

<?php $__env->stopSection(); ?>
<?php echo $__env->make('layouts.appLayout', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\Users\tekh2\Desktop\ecommerce\ecommerce\resources\views/payMcp.blade.php ENDPATH**/ ?>