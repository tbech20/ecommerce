


<?php $__env->startSection('content'); ?>


<div class="dashboardContentContainer">

    <div class="dashboardHeader">

        <div class="dashboardHeaderDetails">

            <p>Somename</p>
            <form action="<?php echo e(url('/logout')); ?>" method="POST">
                <?php echo csrf_field(); ?>
                <button type="submit">Log Out</button>
                </form>

        </div>






    </div>


    <div class="promocodes">



        <div class="addPromocode">

            <form action="<?php echo e(url('/generatePromoCode')); ?>" method="POST">
                <?php echo csrf_field(); ?>

                <p class="text-center">Add a promo code</p>

                <div class="form-group">

                    <label for="code">Code</label>

                    <input type="text" name='code' class="promocodeInput form-control">

                </div>

                <div class="form-group">

                    <label for="discount">Price Discount</label>

                    <input type="text" name='discount' class="promocodeInput form-control">

                </div>

                <button type="submit" class="btn btn-dark">Generate</button>
                <?php if(session('succesfull')): ?>


                <p class="successFullMessage"><?php echo e(session('succesfull')); ?></p>

                <?php endif; ?>
            </form>
        </div>

        <table class="table">

            <tr>

                <th>Id</th>
                <th>Date</th>
                <th>Code</th>
                <th>Discount</th>
                <th>Stauts</th>
                <th>Approve</th>
                <th>Unapprove</th>
                <th>Delete</th>

            </tr>

            <?php $__currentLoopData = $promocodes; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $promocode): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>



            <tr>
                <td><?php echo e($promocode->id); ?></td>
                <td><?php echo e($promocode->created_at->format('j F Y')); ?></td>
                <td><?php echo e($promocode->code); ?></td>
                <td><?php echo e($promocode->priceDiscount); ?></td>
                <td>

                    <?php if($promocode->status == 'approved'): ?>
                    <p class="badge badge-success promocodeStatus"><?php echo e($promocode->status); ?></p>
                    <?php else: ?>

                    <p class="badge badge-danger promocodeStatus"><?php echo e($promocode->status); ?></p>
                    <?php endif; ?>


                </td>
                <td><a class="btn btn-success btn-sm" href="<?php echo e(url('/promocode/approve/'. $promocode->id)); ?>">Approve</a></td>
                <td><a class="btn btn-danger btn-sm" href="<?php echo e(url('/promocode/unapprove/'. $promocode->id)); ?>">Unapprove</a></td>
                <td><a class="btn btn-danger btn-sm" href="<?php echo e(url('/promocode/delete/'. $promocode->id)); ?>">Delete</a></td>

            </tr>

            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>




        </table>



    </div>




</div>


<?php $__env->stopSection(); ?>


<?php $__env->startSection('scripts'); ?>



<?php $__env->stopSection(); ?>
<?php echo $__env->make('layouts.dashboardLayout', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\Users\tekh2\Desktop\ecommerce\ecommerce\resources\views/promocodes.blade.php ENDPATH**/ ?>