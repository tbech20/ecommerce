


<?php $__env->startSection('content'); ?>


<div class="dashboardContentContainer">

    <div class="dashboardHeader">

        <div class="dashboardHeaderDetails">

            <p>Somename</p>
            <form action="<?php echo e(url('/logout')); ?>" method="POST">
                <?php echo csrf_field(); ?>
                <button type="submit">Log Out</button>
            </form>

        </div>



    </div>


    <div class="subscribers">


        <?php if(session('deleted')): ?>


        <p class="successFullMessage"><?php echo e(session('deleted')); ?></p>

        <?php endif; ?>


        <table class="table">

            <tr>

                <th>Id</th>
                <th>Date</th>
                <th>Email</th>
                <th>Delete</th>


            </tr>

            <?php $__currentLoopData = $subscribers; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $subscriber): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>



            <tr>
                <td><?php echo e($subscriber->id); ?></td>
                <td><?php echo e($subscriber->created_at->format('j F Y')); ?></td>
                <td><?php echo e($subscriber->email); ?></td>
                <td><a class="btn btn-danger btn-sm" href="<?php echo e(url('/admin/subscriber/delete/'.$subscriber->id)); ?>">Delete</a></td>

            </tr>

            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>




        </table>



    </div>




</div>


<?php $__env->stopSection(); ?>


<?php $__env->startSection('scripts'); ?>



<?php $__env->stopSection(); ?>
<?php echo $__env->make('layouts.dashboardLayout', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\Users\tekh2\Desktop\ecommerce\ecommerce\resources\views/subscribers.blade.php ENDPATH**/ ?>