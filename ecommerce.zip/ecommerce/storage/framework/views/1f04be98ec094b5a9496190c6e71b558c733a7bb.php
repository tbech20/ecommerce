

<?php $__env->startSection('styles'); ?>

<link href="<?php echo e(asset('/css/login.css')); ?>" rel="stylesheet">

<?php $__env->stopSection(); ?>


<?php $__env->startSection('content'); ?>


<div class="loginContainer">

    <div class="login">


        <h2>Login</h2>
        <form action="/admin/login" method="POST">
            <?php echo csrf_field(); ?>
            <div class="loginInputs">



                <input autofocus type="text" name='username' placeholder="Username">
                <input type="password" name='password' placeholder="Password">

                <?php if(session('loginError')): ?>

                <p class="error"><?php echo e(session('loginError')); ?></p>


                <?php endif; ?>

            </div>

            <button class="loginSubmitBtn" type="submit">Login</button>


    </div>
    </form>
</div>

<?php $__env->stopSection(); ?>
<?php echo $__env->make('layouts.appLayout', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\Users\tekh2\Desktop\ecommerce\ecommerce\resources\views/login.blade.php ENDPATH**/ ?>