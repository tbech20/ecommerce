


<?php $__env->startSection('styles'); ?>

<link href="<?php echo e(asset('/css/productStyles.css')); ?>" rel="stylesheet">

<?php $__env->stopSection(); ?>


<?php $__env->startSection('content'); ?>


<div class="productContainer">

    <div class="productMiddleContainer">


        <div class="productLeftContainer">

            <div class="productLeftTop">

                <img class="productMainIMage" src="<?php echo e(url('storage/images/'.$product->mainImage)); ?>" alt="">

            </div>


            <div class="productLeftBottom">

                <img class="productSmallImage productSmallImageActive" src="<?php echo e(url('storage/images/'.$product->subImage1)); ?>" alt="">
                <img class="productSmallImage" src="<?php echo e(url('storage/images/'.$product->subImage2)); ?>" alt="">
                <img class="productSmallImage" src="<?php echo e(url('storage/images/'.$product->subImage3)); ?>" alt="">
                <img class="productSmallImage" src="<?php echo e(url('storage/images/'.$product->subImage4)); ?>" alt="">
                <img class="productSmallImage" src="<?php echo e(url('storage/images/'.$product->subImage5)); ?>" alt="">

            </div>


        </div>


        <div class="productRightContainer">

            <p class="productFirstLine"><?php echo e($product->title); ?></p>
            <h2 class="productName"><?php echo e($product->name); ?></h2>

            <div class="productRating">

                <i class="fas fa-star"></i>
                <p><?php echo e($product->rating); ?></p>

            </div>


            <div class="productDiscountValues">

                <p class="productValue"> $<?php echo e($product->price); ?> </p>

                <p class="productDiscountValue"> $<?php echo e($product->salePrice); ?> </p>

            </div>

            <p class="productDescription"><?php echo e($product->description); ?></p>
            <p class="productCategory">Category: <?php echo e($product->category); ?></p>
            <p class="productStock">Stock: <?php echo e($product->stock); ?></p>
            <div class="form-group productForm">
                <label for="">Select Quantity</label>

                <form action="<?php echo e(url('/addcart/'.$product->id)); ?>">
                    <select value="" name='qty' class="form-control">


                        <option value="1">1</option>
                        <option value="2">2</option>
                        <option value="3">3</option>

                    </select>

                    <?php echo csrf_field(); ?>
                    <button class="addToCartBtn">Add To Cart</button>
                </form>
            </div>




        </div>


    </div>


</div>


<?php $__env->stopSection(); ?>
<?php echo $__env->make('layouts.appLayout', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\Users\tekh2\Desktop\ecommerce\ecommerce\resources\views/product.blade.php ENDPATH**/ ?>