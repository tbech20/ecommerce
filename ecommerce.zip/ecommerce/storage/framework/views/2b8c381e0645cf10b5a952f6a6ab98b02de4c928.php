


<?php $__env->startSection('content'); ?>


<div class="dashboardContentContainer">

    <div class="dashboardHeader">

        <div class="dashboardHeaderDetails">

            <p>Somename</p>
            <form action="<?php echo e(url('/logout')); ?>" method="POST">
                <?php echo csrf_field(); ?>
                <button type="submit">Log Out</button>
                </form>

        </div>



    </div>


    <div class="credentials">


        <form action="<?php echo e(url('/changecredentials')); ?>" method="POST" class="credentialsForm">
            <?php echo csrf_field(); ?>
            <div class="form-group">

                <label for="username">Username</label>
                <input type="text" required class="form-control" value="<?php echo e($user->name); ?>" name='username' placeholder="Username">


            </div>


            <div class="form-group">

                <label for="password">Password</label>
                <input type="text" class="form-control" name='password' placeholder="Password">


            </div>

            <button class="credentialsSubmitBtn">Change Credentials</button>

            <?php if(session('successfull')): ?>

            <p class="successfullyUpdatedCredentials"><?php echo e(session('successfull')); ?></p>

            <?php endif; ?>

        </form>



    </div>


</div>


<?php $__env->stopSection(); ?>
<?php echo $__env->make('layouts.dashboardLayout', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\Users\tekh2\Desktop\ecommerce\ecommerce\resources\views/credentials.blade.php ENDPATH**/ ?>