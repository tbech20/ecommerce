


<?php $__env->startSection('content'); ?>


<div class="dashboardContentContainer">

    <div class="dashboardHeader">

        <div class="dashboardHeaderDetails">

            <p>Somename</p>

            fo
            <form action="<?php echo e(url('/logout')); ?>" method="POST">
                <?php echo csrf_field(); ?>
                <button type="submit">Log Out</button>
                </form>

        </div>



    </div>


    <div class="allproducts">

        <?php if(session('deleted')): ?>

        <p class="successFullMessage"><?php echo e(session('deleted')); ?></p>

        <?php endif; ?>




        <table class="table">

            <tr>

                <th>Name</th>
                <th>Title</th>
                <th>Sale Price</th>
                <th>Price</th>
                <th>Stock</th>
                <th>Category</th>
                <th>Edit</th>
                <th>Delete</th>
                <th>View</th>

            </tr>

            <?php $__currentLoopData = $products; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $product): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>



            <tr>

                <td><?php echo e($product->name); ?></td>
                <td><?php echo e($product->title); ?></td>
                <td>$<?php echo e($product->salePrice); ?></td>
                <td>$<?php echo e($product->price); ?></td>
                <td><?php echo e($product->stock); ?></td>
                <td><?php echo e($product->category); ?></td>
                <td><a class="btn btn-info" href="<?php echo e(url('/admin/product/edit/'.$product->id)); ?>">Edit</a></td>


                <td><a class="btn btn-danger" href="<?php echo e(url('/admin/product/delete/'.$product->id)); ?>">Delete</a></td>
                <td><a class="btn btn-info" href="<?php echo e(url('/product/'.$product->id)); ?>">View</a></td>

            </tr>

            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>




        </table>



    </div>




</div>


<?php $__env->stopSection(); ?>


<?php $__env->startSection('scripts'); ?>



<?php $__env->stopSection(); ?>
<?php echo $__env->make('layouts.dashboardLayout', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\Users\tekh2\Desktop\ecommerce\ecommerce\resources\views/allproducts.blade.php ENDPATH**/ ?>