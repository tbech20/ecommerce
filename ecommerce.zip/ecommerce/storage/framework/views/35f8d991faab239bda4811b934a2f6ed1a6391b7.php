


<?php $__env->startSection('content'); ?>


<div class="dashboardContentContainer">

    <div class="dashboardHeader">

        <div class="dashboardHeaderDetails">

            <p>Somename</p>
            <form action="<?php echo e(url('/logout')); ?>" method="POST">
                <?php echo csrf_field(); ?>
                <button type="submit">Log Out</button>
            </form>

        </div>



    </div>


    <div class="orders">


        <table class="table">

            <tr>

                <th>Date</th>
                <th>Email</th>
                <th>Price</th>
                <th>Order Id</th>
                <th>Status</th>
                <th>Wait order</th>
                <th>Complete order</th>
                <th>View</th>

            </tr>

            <?php $__currentLoopData = $orders; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $order): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>



            <tr>


                <td><?php echo e($order->created_at->format('j F Y')); ?></td>
                <td><?php echo e($order->userEmail); ?></td>
                <td>$<?php echo e($order->price); ?></td>
                <td><?php echo e($order->id); ?></td>
                <?php if($order->status == 'pending'): ?>
                <td>
                    <p class="badge badge-info orderStatus"><?php echo e($order->status); ?></p>
                </td>
                <?php else: ?>

                <td>
                    <p class="badge badge-success orderStatus"><?php echo e($order->status); ?></p>
                </td>
                <?php endif; ?>
                <td><a class="btn btn-info btn-sm" href="<?php echo e(url('/order/wait/'.$order->id)); ?>">Wait Order</a></td>
                <td><a class="btn btn-success btn-sm" href="<?php echo e(url('/order/complete/'.$order->id)); ?>">Complete Order</a></td>
                <td><a class="btn btn-info btn-sm" href="<?php echo e(url('/order/view/'. $order->id)); ?>">View</a></td>

            </tr>

            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>




        </table>



    </div>




</div>


<?php $__env->stopSection(); ?>


<?php $__env->startSection('scripts'); ?>



<?php $__env->stopSection(); ?>
<?php echo $__env->make('layouts.dashboardLayout', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\Users\tekh2\Desktop\ecommerce\ecommerce\resources\views/orders.blade.php ENDPATH**/ ?>