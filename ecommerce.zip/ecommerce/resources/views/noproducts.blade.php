@extends('layouts.appLayout')

@section('styles')

<link href="{{asset('/css/checkout.css')}}" rel="stylesheet">

@stop


@section('content')


<div class="checkoutContainer noproductsCheckout">

    <div class="checkout">

    </div>


</div>


@stop